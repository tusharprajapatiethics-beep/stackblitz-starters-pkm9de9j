import { Component, ElementRef, OnInit, ViewChild, ViewEncapsulation, ContentChild } from '@angular/core';
import { MediaChange, ObservableMedia } from '@angular/flex-layout';
import { Subscription } from 'rxjs';
import { AuthService } from '../auth/auth.service';
import { CommonService, Logger } from '../common-services/common-functions.service';
import { SharedService } from '../shared/shared.service';
import { NavItem, NavService } from './menu-service/nav.service';

@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class MenuComponent implements OnInit {

  opened = true;
  over = 'side';
  expandHeight = '42px';
  collapseHeight = '42px';
  displayMode = 'flat';
  stickClass = 'leak_add';
  pageArray = {
    companyList: []
  }
  @ContentChild('appDrawer', { static: false }) appDrawer: ElementRef;
  watcher: Subscription;
  userFullName;
  constructor(media: ObservableMedia,
    private navService: NavService,
    private authService: AuthService,
    public sharedService: SharedService) {
    this.watcher = media.subscribe((change: MediaChange) => {
      if (change.mqAlias === 'sm' || change.mqAlias === 'xs') {
        this.opened = false;
        this.over = 'over';
      } else {
        this.opened = true;
        this.over = 'side';
      }
    });
    this.userFullName = authService.getFullName;
    this.loadDefaultData();
  }

  navItems: NavItem[] = [
    {
      title: 'Dashboard',
      icon: 'dashboard',
      link: '',
    },
    {
      title: 'Admin',
      icon: 'security',
      children: [
        {
          title: 'Users',
          icon: 'supervised_user_circle',
          link: '/cpos/admin/list',
        },
        {
          title: 'Roles Right',
          icon: 'layers',
          link: '/cpos/admin/rights/1',
        },
        {
          title: 'Users Right',
          icon: 'layers',
          link: '/cpos/admin/rights/2',
        }
      ]
    },
    {
      title: 'Master',
      icon: 'blur_on',
      children: [
        {
          title: 'State',
          icon: 'list_alt',
          link: '/cpos/master/state',
        },
        {
          title: 'City',
          icon: 'list_alt',
          link: '/cpos/master/city',
        },
        {
          title: 'Company',
          icon: 'business',
          link: '/cpos/master/company',
        },
        {
          title: 'Destination',
          icon: 'location_on',
          link: '/cpos/master/destination',
        },
        {
          title: 'Expense',
          icon: 'list_alt',
          link: '/cpos/master/expense',
        },
      ]
    },
  ];

  ngOnInit() {
    Logger.Normal(this.authService.getUserMenu);
    this.navItems = this.authService.getUserMenu as NavItem[];
    this.stickClass = (!this.navService.restrictClose) ? 'leak_add' : 'leak_remove'
  }

  loadDefaultData(): any {

  }

  onStickSideNavClick() {
    if (this.stickClass === 'leak_add') {
      this.stickClass = 'leak_remove'
      this.navService.restrictClose = true;
    } else {
      this.stickClass = 'leak_add'
      this.navService.restrictClose = false;
    }
  }
  LogOut() {
    this.authService.logOut();
  }
}
