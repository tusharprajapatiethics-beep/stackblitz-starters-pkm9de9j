import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { MatDialog } from '@angular/material';
import { Observable, Subject } from 'rxjs';
import { isNullOrUndefined } from 'util';
import { ConfirmationModel, ConfirmationPopupComponent } from '../common-component/confirmation-popup/confirmation-popup.component';
import { Logger } from '../common-services/common-functions.service';
import { AccessLevel, VendorEnum } from '../common-services/enum.service';
import { IShortCutKeys } from '../common-services/interface.service';
import { ApiResponse, CommonFilter } from '../common-services/models.service';

@Injectable()
export class SharedService {

  sharedMaster = {};
  ddl = { 1: { api: 'state/ddlist', list: new Array<any>() } };
  shortCutKeyListner = new Subject<IShortCutKeys>();

  masterUrl = {
    1: { List: 'account/users', 'Save': 'account/create', 'Delete': 'account/delete/', 'Filter': 'payment/filter', 'isExists': '', 'byId': 'account/user/' },
    4: { List: 'vendor/list?search=', byId: 'vendor/bycode?code=' },
    5: { byId: 'po/byid?poid=' }
  };

  searchProgress = false;
  printObject = null;
  formBtn = {
    actionAccess: AccessLevel.None
  };
  constructor(public dialog: MatDialog, private httpClient: HttpClient) { }

  public isEnableOrVisible(no): boolean {
    return (this.formBtn.actionAccess & no) > 0;
  }

  getConfirmatonConfig(header, message) {
    return this.dialog.open(ConfirmationPopupComponent, {
      width: '400px',
      data: new ConfirmationModel(header, message),
      disableClose: true,
      closeOnNavigation: true
    });
  }

  getSearchFilter(page: VendorEnum): CommonFilter {
    if (isNullOrUndefined(this.sharedMaster[page])) {
      this.sharedMaster[page] = new FilterObject(new CommonFilter('', page));
    }
    return this.sharedMaster[page].searchFilter;
  }

  searchDropdownList(ddlFor, param: string = '') {
    return this.httpClient.get(this.ddl[ddlFor].api + param).map((t: ApiResponse) => t.data);
  }

  getDropdownList(ddlFor) {
    const obj = this.ddl[ddlFor];
    if (!isNullOrUndefined(obj)) {
      if (!isNullOrUndefined(obj.list) && obj.list.length > 0) {
        return Observable.of(obj.list);
      } else {
        return this.httpClient.get(obj.api).map((t: any) => {
          if (t.status === true) {
            this.ddl[ddlFor].list = t.data;
            return t.data;
          } else {
            return Observable.throw(t.message);
          }
        });
      }
    } else {
      Logger.Warn(`getDropdownList Not Exists ${ddlFor}`);
      return Observable.of(null);
    }
  }


  getDropdownName(id: number, pageNo: VendorEnum, matchkey = 'id', resultKey = 'name') {
    let name = '';
    if (!isNullOrUndefined(id) && id > 0) {
      const list: any = this.getDropdownList(pageNo);
      if (!isNullOrUndefined(list) && list.value.length > 0) {
        list.value.filter((e) => {
          if (e[matchkey] == id) {
            name = e[resultKey];
          }
        });
      }
    }
    return name;
  }

  filter(master: VendorEnum, param1: any = null, queryParam: any = null): Observable<any> {
    if (!isNullOrUndefined(queryParam)) {
      return this.httpClient.post<ApiResponse>(this.masterUrl[master].Filter + queryParam, param1).map(t => t);
    } else {
      return this.httpClient.post<ApiResponse>(this.masterUrl[master].Filter, param1).map(t => t);
    }
  }

  getFilter(filter): Observable<any> {
    return this.httpClient.post<any[]>('common/filter', filter).map(t => t);
  }

  getList(master: VendorEnum, param1: any = ''): Observable<any> {
    return this.httpClient.get<any[]>(this.masterUrl[master].List + param1).map(t => t);
  }

  save(master: VendorEnum, param1: any = null, queryParam: any = null): Observable<ApiResponse> {
    return this.httpClient.post<ApiResponse>(this.masterUrl[master].Save, param1).map(t => t);
  }

  isExists(master: VendorEnum, param1: any = null): Observable<ApiResponse> {
    return this.httpClient.get<ApiResponse>(this.masterUrl[master].isExists + param1);
  }

  byId(master: VendorEnum, param1: any = null): Observable<any> {
    return this.httpClient.get<ApiResponse>(this.masterUrl[master].byId + param1).map(t => t);;
  }

  delete(master: VendorEnum, param1: any = null, queryParam: any = null): Observable<any> {
    return this.httpClient.post<any>(this.masterUrl[master].Delete, param1).map(t => t);
  }

  deleteById(master: VendorEnum, param1: any = null, queryParam: any = null): Observable<any> {
    return this.httpClient.get<any>(this.masterUrl[master].Delete + param1).map(t => t);
  }

  customGetApi(api: string): Observable<ApiResponse> {
    return this.httpClient.get<ApiResponse>(api).map(t => t);
  }

  customPostApi(api: string, data: any): Observable<ApiResponse> {
    return this.httpClient.post<ApiResponse>(api, data).map(t => t);
  }

  previewImage(url: string, filePath: string): Observable<any> {
    if (!isNullOrUndefined(filePath) && filePath !== '') {
      return this.httpClient.get(url + filePath, { responseType: 'blob', observe: 'response' });
    } else {
      return Observable.of(null);
    }
  }


}

export class FilterObject {
  constructor(private _searchFilter: any = null, private _dataSource: any = null) {
    this.searchFilter = isNullOrUndefined(_searchFilter) ? new CommonFilter('') : _searchFilter;
    this.dataSource = _dataSource;
  }
  searchFilter: CommonFilter;
  dataSource = [];
}

// let expenseName = '';
    // if (!isNullOrUndefined(expenseID) && expenseID > 0) {
    //   const list: any = this.getDropdownList(MastersEnum.Expense);
    //   if (!isNullOrUndefined(list) && list.value.length > 0) {
    //     list.value.filter((e) => {
    //       if (e.id == expenseID) {
    //         expenseName = e.name;
    //       }
    //     });
    //   }
    // }
    // return expenseName;