// import { Pipe, PipeTransform } from '@angular/core';
// import { CommonService } from '../common-services/common-functions.service';

// @Pipe({
//     name: 'myfilter',
//     pure: false
// })
// export class FilterPipe implements PipeTransform {
//     transform(items: any[], filter: Object): any {

//         if (!items || !filter) {
//             return items;
//         }
//         const keyName = CommonService.getKeyName(filter);
//         // filter items array, items which match and return true will be
//         // kept, false will be filtered out
//         return items.filter(item => item[keyName].indexOf(filter[keyName]) !== -1);
//     }
// }
