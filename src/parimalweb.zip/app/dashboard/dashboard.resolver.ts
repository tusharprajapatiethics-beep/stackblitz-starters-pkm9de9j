import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, Resolve, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { AuthService } from '../auth/auth.service';
import { AdminService } from '../cpos-modules/admin/admin.service';

@Injectable()
export class DashboardResolver implements Resolve<any> {
    // filter = new CommonFilter('');
    batchNoparam: any;
    constructor(private authService: AuthService,private adminService: AdminService) {
        // this.filter.pageNumber = 1;
        // this.filter.pageSize= this.authService.AppConfig.gridItemsPerPage;
    }

    resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<any[]> {
        const currentUrl = route.data['dataFor'];
        if (currentUrl.startsWith('dashboard')) {
            // return this.adminService.getGetDefaultDashboardData(null);
        }
        return null;
    }
}