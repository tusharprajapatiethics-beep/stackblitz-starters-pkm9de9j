import { Component, OnInit } from '@angular/core';
import { SnackBarService } from '../../common-services/snack-bar.service';

@Component({
  selector: 'app-admin-dashboard',
  templateUrl: './admin-dashboard.component.html',
  styleUrls: ['./admin-dashboard.component.css']
})
export class AdminDashboardComponent implements OnInit {

  constructor(private notification: SnackBarService) { }

  ngOnInit() {
    // this.notification.success('snackbar-component works! snackbar-component works');
  }

  // showMessage() {
  //   this.notification.error('snackbar-component works! snackbar-component works');
  // }

}
