import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdminDashboardComponent } from './admin-dashboard/admin-dashboard.component';
import { DashboardResolver } from './dashboard.resolver';
import { AuthGuard } from '../auth/auth.guard';
import { DashboardComponent } from './dashboard/dashboard.component';
import { MatGridListModule, MatCardModule, MatMenuModule, MatIconModule, MatButtonModule } from '@angular/material';
import { LayoutModule } from '@angular/cdk/layout';
import { Ng2GoogleChartsModule } from '../../../node_modules/ng2-google-charts';
import { AdminService } from '../cpos-modules/admin/admin.service';

const routes: Routes = [
  {
    path: '', component: DashboardComponent,
    resolve: { data: DashboardResolver },
    canActivate: [AuthGuard],
    data: { dataFor: 'dashboard', rights: '{"0": 1 }' },
  },
];

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    MatGridListModule,
    MatCardModule,
    MatMenuModule,
    MatIconModule,
    MatButtonModule,
    LayoutModule,
    Ng2GoogleChartsModule
  ],
  declarations: [AdminDashboardComponent, DashboardComponent],
  providers: [DashboardResolver,AdminService]
})
export class DashbordModule { }
