import { BreakpointObserver, Breakpoints } from '@angular/cdk/layout';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { map } from 'rxjs/operators';
import { AdminService } from '../../cpos-modules/admin/admin.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css'],
})
export class DashboardComponent implements OnInit {

  /** Based on the screen size, switch from standard to one column per row */
  rowHeight = '200px';
  pivotdata: any = [];
  data = {};
  cards = this.breakpointObserver.observe(Breakpoints.Handset).pipe(
    map(({ matches }) => {
      if (matches) {
        return [
          { title: 'Card 1', cols: 1, rows: 1, id: 1, height: 70 },
          { title: 'Card 2', cols: 1, rows: 1, id: 2, height: 70 },
          { title: 'Card 3', cols: 1, rows: 1, id: 3, height: 70 },
          { title: 'Card 4', cols: 1, rows: 1, id: 4, height: 70 }
        ];
      }

      return [
        { title: 'Quarterly Sales', cols: 1, rows: 1, id: 3, height: 10 },
        { title: 'Real Time - Stock CWH', cols: 1, rows: 1, id: 2, height: 10 },
        { title: 'Weekly Top 10 Performer (as per Sale)', cols: 2, rows: 1, id: 1, height: 10 },
        { title: 'Weekly Top 10 Lowest Performer (as per Sale)', cols: 2, rows: 1, id: 4, height: 10 }
      ];
    })
  );

  pieChartData = {
    chartType: 'PieChart',
    dataTable: [],
    options: {
      'title': 'Quarter Data',
      colors: ['#FF9EB3', '#FFE299', '#82CDFF', '#BBDEFB', '#BDBDBD'],
      fontName: 'Segoe UI',
      fontSize: 14,
      backgroundColor: 'transparent',
      pieHole: 0.5,
      pieSliceBorder: 50,

      height: 300,
      width: '100%',
      legend: 'none',
      chartArea: {
        left: "3%",
        top: "3%",
        height: "94%",
        width: "94%"
      }

    },
  };

  columnChartData = {
    chartType: 'ColumnChart',
    dataTable: [],
    options: {
      'title': 'Top Performer',
      height: 300,
      width: '100%',
      colors: ['#FF9EB3', '#FFE299', '#82CDFF', '#BBDEFB', '#BDBDBD'],
      fontName: 'Segoe UI',
      fontSize: 14,
      seriesType: "bars",
      series: { 5: { type: "line" } },
      animation: {
        duration: 1000,
        easing: 'in'
      }
    },
  };

  LineChartData = {
    chartType: 'LineChart',
    dataTable: [],
    options:
    {
      'title': 'Stock Per Warehouse',
      colors: ['#FFE299', '#82CDFF', '#BBDEFB', '#BDBDBD'],
      fontName: 'Segoe UI',
      fontSize: 14,
      height: 300,
      width: '100%',
      chartArea: {
        left: "10%",
        top: "3%",
        'width': '70%',
        'height': '70%'
      },
      animation: {
        startup: true,
        duration: 2000,
        easing: 'out',
      }
    },
  };

  columnLowestChartData = {
    chartType: 'ColumnChart',
    dataTable: [],
    formatter: { direction: -1 },
    options: {
      'title': 'Lowest Performer',
      height: 300,
      width: '100%',
      colors: ['#FFE299', '#82CDFF', '#BBDEFB', '#BDBDBD', '#FF9EB3'],
      fontName: 'Segoe UI',
      fontSize: 14,
      seriesType: "bars",
      series: { 5: { type: "line" } },
      animation: {
        duration: 1000,
        easing: 'out'
      }
    }
  };


  constructor(private breakpointObserver: BreakpointObserver,
    public adminService: AdminService,
    private activateRoute: ActivatedRoute) { }

  ngOnInit(): void {

    this.activateRoute.data.subscribe((resp) => {
      if (resp && resp.data) {
        this.fillQuarterlySalesData(resp.data.quarterData);
        this.fillWarehouseStockData(resp.data.warehouseStock);
        this.fillWeeklyTopPerformer(resp.data.topPerformer);
        this.fillWeeklyLowestPerformer(resp.data.lowestPerformer);
        this.getPivotData(resp.data.topPerformer);

        this.data[1] = this.columnChartData;
        this.data[2] = this.LineChartData;
        this.data[3] = this.pieChartData;
        this.data[4] = this.columnLowestChartData;
      }
    });

    setTimeout(() => {
      this.rowHeight = `${(document.getElementById('mainSection').clientHeight / 3) - 21}px`;
    }, 250);
  }

  fillQuarterlySalesData(data) {
    this.pieChartData.dataTable.push(['Quarter Data', 'Sales per Quarter']);
    this.pieChartData.dataTable.push(['1st Quarter', data[0].quarter1]);
    this.pieChartData.dataTable.push(['2nd Quarter', data[0].quarter2]);
    this.pieChartData.dataTable.push(['3rd Quarter', data[0].quarter3]);
    this.pieChartData.dataTable.push(['4th Quarter', data[0].quarter4]);
  }

  fillWarehouseStockData(data) {
    this.LineChartData.dataTable.push(['Warehouse Name', 'Stock per DC']);
    for (const item of data) {
      this.LineChartData.dataTable.push([item.warehouseName, item.quantity]);
    }
  }

  fillWeeklyTopPerformer(data) {
    this.columnChartData.dataTable.push(['Days', 'South', 'East', 'West', 'North', 'Other']);
    for (const item of data) {
      this.columnChartData.dataTable.push([item.dayName, item.southern, item.eastern, item.western, item.northern, item.other])
    }
  }

  fillWeeklyLowestPerformer(data) {
    this.columnLowestChartData.dataTable.push(['Days', 'South', 'East', 'West', 'North', 'Other']);
    for (const item of data) {
      this.columnLowestChartData.dataTable.push([item.dayName, item.southern, item.eastern, item.western, item.northern, item.other])
    }
  }

  getPivotData(data) {
    this.pivotdata.push(['Days', 'South', 'East', 'West', 'North', 'Other']);
    for (const item of data) {
      this.pivotdata.push([item.dayName, item.southern, item.eastern, item.western, item.northern, item.other])
    }
  }

  getChartData(card) {
    if (card.id === 3) {
      return this.pieChartData;
    } else if (card.id === 2) {
      return this.LineChartData;
    } else {
      return null;
    }
  }
}
