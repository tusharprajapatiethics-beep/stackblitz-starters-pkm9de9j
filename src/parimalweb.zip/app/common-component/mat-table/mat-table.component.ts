import { Component, ContentChild, EventEmitter, Input, OnDestroy, OnInit, Output, ViewEncapsulation, ViewChild, TemplateRef } from '@angular/core';
import { FormControl, Validators } from '@angular/forms';
import { MatDialog, MatDialogRef, MatPaginator, MatSort, MatTableDataSource } from '@angular/material';
import { Subscription } from 'rxjs';
import { isDate } from 'rxjs/internal/util/isDate';
import { isNullOrUndefined, isUndefined } from 'util';
import { AuthService } from '../../auth/auth.service';
import { CommonService } from '../../common-services/common-functions.service';
import { AccessLevel, InputType, ShortCutKeys, VendorEnum } from '../../common-services/enum.service';
import { IFilterGridInput, IHashTable, IShortCutKeys } from '../../common-services/interface.service';
import { CommonFilter } from '../../common-services/models.service';
import { SharedService } from '../../shared/shared.service';
import { FilterGridComponent } from '../filter-grid/filter-grid.component';


@Component({
  selector: 'app-mat-table',
  templateUrl: './mat-table.component.html',
  styleUrls: ['./mat-table.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class MatTableComponent implements OnInit, OnDestroy {


  displayedColumns: string[] = [];
  headerColumns: string[] = [];
  columnsDataType: InputType[] = [];
  searchFieldDDL = [];
  actionButton = AccessLevel;
  tableProperties: TableObject;
  footerDatasource = {};
  tooltipFields = new Map();
  filterPlaceHolder = 'Filter';
  filterValidationError = '';
  selectedRow: any;
  selectedOn = '';
  filterObj = {
    field: new FormControl(null, Validators.required),
    value: new FormControl(null),
  };
  advanceSearchObject: IFilterGridInput;
  clsfilter: CommonFilter;
  filterObject = {};
  chipDisplayObj = {};
  @Input() tableHeight: number;
  @Input() showFilter = true;
  tableSource: MatTableDataSource<any>;
  private watcher: Subscription;
  private subscription: Subscription;
  private dialogRef: MatDialogRef<FilterGridComponent>;
  hLRowId: 0;
  footerDisplay = false;
  tableFirstRow = null;
  @Input() set hightLightRowId(v: any) {
    this.hLRowId = v;
    setTimeout(() => {
      this.hLRowId = 0;
    }, 3200);
  }

  @Input() set dataSource(v: any) {
    this.tableSource = v;
    this.footerDisplay = false;
    if (!isNullOrUndefined(this.tableProperties) && !this.tableProperties.isServerSidePaging) {
      this.tableSource.paginator = this.paginator;
      this.tableSource.sort = this.sort;
    }
    if (this.tableSource.data && this.tableSource.data.length > 0) {
      this.tableFirstRow = this.tableSource.data[0];
    }

    if (this.tableProperties && this.tableFirstRow) {
      this.setDefaultFooter(this.tableProperties.cellDefArray, this.getCurrentPageData);
    }
  };
  @Input() inProgress = false;
  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort: MatSort;
  @Output() action = new EventEmitter<{ actionButon: AccessLevel, data: any }>();
  @Output() filter = new EventEmitter<{ filter: CommonFilter }>();
  @Input() set tableConfiguration(t: TableObject) {
    if (!isNullOrUndefined(t)) {
      this.displayedColumns = CommonService.getColumnAsArray(t.cellDefArray, 'displayName');
      this.headerColumns = CommonService.getColumnAsArray(t.cellDefArray, 'headerName');
      this.columnsDataType = CommonService.getColumnAsArray(t.cellDefArray, 'fieldType');
      this.tableProperties = t;
      this.searchFieldDDL = t.cellDefArray.filter((t: cellDef) => {
        if (t.showInFieldDDl === true) {
          if (t.fieldType === InputType.Date) {
            this.chipDisplayObj[t.displayName + '_from'] = { headerName: t.headerName + ' From', inputType: t.fieldType };
            this.chipDisplayObj[t.displayName + '_to'] = { headerName: t.headerName + ' To', inputType: t.fieldType };
          } else {
            this.chipDisplayObj[t.displayName] = { headerName: t.headerName, inputType: t.fieldType };
          }
          return t;
        }
      });
      if (!isNullOrUndefined(t.deaultFilter)) { this.clsfilter = t.deaultFilter; }
      this.selectedOn = (this.displayedColumns.length > 0 && (isNullOrUndefined(t.defaultSearchField) || t.defaultSearchField === '')) ? this.displayedColumns[0] : t.defaultSearchField;
      this.clsfilter.searchField = this.selectedOn;
      this.advanceSearchObject = { searchCell: this.searchFieldDDL, pageEnum: t.pageEnum, prevSearch: t.deaultFilter.filterArray, focusControl: this.clsfilter.searchField } as IFilterGridInput;
      this.clearFilter();

      if ((this.authService.pageAccessLevel & this.tableProperties.actionButton) > 0) {
        this.displayedColumns.push('action');
        this.headerColumns.push('Action');
      }
      if (!this.tableProperties.isServerSidePaging) {
        this.tableSource.paginator = this.paginator;
        this.tableSource.sort = this.sort;
        this.tableSource.filterPredicate = this.createFilter();
        if (!isNullOrUndefined(this.clsfilter.searchField) && this.clsfilter.searchField.trim() !== '' && !isNullOrUndefined(this.clsfilter.searchValue) && this.clsfilter.searchValue !== '') {
          this.filterObject[this.clsfilter.searchField] = this.clsfilter.searchValue.trim().toLowerCase();
          this.filterLocalEvent();
        }
      }
      this.setFilterObject();
      this.onFilterChangeEvent(this.selectedOn);
      if ((isNullOrUndefined(this.footerDatasource) || Object.keys(this.footerDatasource).length == 0))
        this.setDefaultFooter(t.cellDefArray, this.getCurrentPageData);

      if ((isNullOrUndefined(this.tooltipFields) || this.tooltipFields.size == 0))
        this.setTooltipField(t.cellDefArray);

    }
  }

  constructor(private authService: AuthService, private sharedService: SharedService, public dialog: MatDialog) {
    this.clsfilter = new CommonFilter(this.authService.VendorCode);
    this.watcher = this.sharedService.shortCutKeyListner.subscribe((t: IShortCutKeys) => {
      this.shortcutKeyEvent(t);
    });
  }

  shortcutKeyEvent(t: IShortCutKeys) {
    switch (t.key) {
      case ShortCutKeys.PageDown:
        if (this.paginator.hasPreviousPage()) {
          this.paginator.previousPage();
        }
        break;
      case ShortCutKeys.PageUp:
        if (this.paginator.hasNextPage()) {
          this.paginator.nextPage();
        }
        break;
      case ShortCutKeys.Home:
        if (this.paginator.hasPreviousPage()) {
          this.paginator.firstPage();
        }
        break;
      case ShortCutKeys.End:
        if (this.paginator.hasNextPage()) {
          this.paginator.lastPage();
        }
        break;
      case ShortCutKeys.AltA:
        this.openDialog();
        break;
      case ShortCutKeys.Alt3:
        this.exportReport();
        break;
      case ShortCutKeys.AltC:
        this.action.emit({ actionButon: AccessLevel.Discard, data: null });
        break;
      default:
        break;
    }
  }

  compState = (val1: string, val2: string) => val1 == val2;
  ngOnInit() {
    this.subscription = this.filterObj.value.valueChanges
      .debounceTime(600)
      .distinctUntilChanged()
      .subscribe(newValue => {
        if (this.filterObj.value.valid) {
          this.clsfilter.searchValue = isNullOrUndefined(newValue) ? '' : newValue.trim().toLowerCase();
          this.clsfilter.searchField = this.filterObj.field.value;
          if (!this.tableProperties.isServerSidePaging) {
            this.filterObject[this.filterObj.field.value] = this.clsfilter.searchValue;
            this.filterLocalEvent();
            this.setDefaultFooter(this.tableProperties.cellDefArray, this.getCurrentPageData);
          }

          if (this.clsfilter.searchValue === '' && !isNullOrUndefined(this.filterObj.field.value)) {
            this.removeFilterObject({ key: this.filterObj.field.value, value: '' });
          } else {
            this.updateObject({ key: this.filterObj.field.value, value: this.clsfilter.searchValue });
          }

          this.clsfilter.pageNumber = 1;
          if (this.paginator.hasPreviousPage()) {
            this.paginator.firstPage();
          } else {
            this.filter.emit({ filter: this.clsfilter });
          }
        }
      });
    // this.tableSource.filter = isNullOrUndefined(newValue) ? '' : newValue.trim().toLowerCase();
  }

  setFilterObject() {
    this.filterObj.field.patchValue((isUndefined(this.clsfilter.searchField) ? null : this.clsfilter.searchField));
    this.filterObj.value.patchValue((isUndefined(this.clsfilter.searchValue) ? null : this.clsfilter.searchValue));
  }

  setTooltipField(cellDefArray: cellDef[]) {
    cellDefArray.forEach((cell: cellDef) => {
      if (cell.tooltipField) {
        this.tooltipFields.set(cell.displayName, cell.tooltipField);
      }
    });
  }

  public isVisible(accessNo: number): boolean {
    if ((this.authService.pageAccessLevel & this.tableProperties.actionButton) > 0) {
      return (this.tableProperties.actionButton & accessNo) > 0;
    } else {
      return false;
    }
  }

  onActionButtonClick(item: any, _actionButon: AccessLevel) {
    this.selectedRow = item;
    this.action.emit({ actionButon: _actionButon, data: item });
  }

  exportReport() {
    this.action.emit({ actionButon: AccessLevel.Export, data: null });
  }

  onPageChange(event) {
    this.clsfilter.currentPage = this.tableProperties.pageEnum;
    this.clsfilter.pageSize = event.pageSize;
    this.clsfilter.pageNumber = event.pageIndex + 1;
    this.clsfilter.searchField = this.filterObj.field.value;
    this.clsfilter.searchValue = this.filterObj.value.value;
    this.filter.emit({ filter: this.clsfilter });
    if (!this.tableProperties.isServerSidePaging) {
      this.setDefaultFooter(this.tableProperties.cellDefArray, this.getCurrentPageData);
    }
  }


  public get getCurrentPageData() {
    if (this.tableSource && this.tableSource.filteredData.length > 0 && !this.tableProperties.isServerSidePaging) {
      const startIndex = this.paginator.pageIndex * ((this.paginator.pageSize) ? this.paginator.pageSize : 10);
      const endIndex = startIndex + ((this.paginator.pageSize) ? this.paginator.pageSize : 10);
      return this.tableSource.filteredData.slice(startIndex, endIndex);
    } else {
      return null;
    }
  }

  onSortData(event) {
    this.clsfilter.pageNumber = 1;
    if (this.paginator.hasPreviousPage()) {
      this.paginator.firstPage();
    }
    this.clsfilter.orderBy = `${event.active} ${event.direction}`
    this.filter.emit({ filter: this.clsfilter });
  }

  public get getTotalLength() {
    if (!isNullOrUndefined(this.tableSource) && this.tableSource.data.length > 0) {
      if (!this.tableProperties.isServerSidePaging) {
        return this.tableSource.data.length;
      } else {
        return this.tableSource.data[0].totalRecord;
      }
    }
    return 0;
  }

  onFilterChangeEvent(event) {
    if (!isNullOrUndefined(event)) {
      this.filterObj.value.setValidators(null);
      this.filterObj.value.disabled ? this.filterObj.value.enable() : null;
      this.searchFieldDDL.filter((t: cellDef) => {
        if (t.displayName === event) {
          this.filterPlaceHolder = `Filter with ${t.headerName}`;
          switch (t.fieldType) {
            case InputType.Phone:
            case InputType.Mobile:
            case InputType.Number:
            case InputType.Amount:
              this.filterObj.value.setValidators([Validators.pattern(CommonService.regExPatern.number)]);
              this.filterValidationError = 'Invalid input';
              break;
            case InputType.Date:
              this.advanceSearchObject.focusControl = this.clsfilter.searchField;
              this.filterObj.value.reset();
              this.filterObj.value.disable();
              this.openDialog();
              break;
            default:
              break;
          }
        }
      });
    }
  }

  setDefaultFooter(cellDefArr: Array<cellDef>, currentPageItems = null) {
    if (this.tableFirstRow && this.tableSource && this.tableSource.data) {
      cellDefArr.forEach((cell: cellDef) => {
        if (cell.footerField && cell.footerField != '') {
          this.footerDisplay = true;
          const val = this.tableSource.data.reduce((sum, j) => sum + CommonService.validateNumber(j[cell.displayName]), 0);
          if (!isNullOrUndefined(this.tableProperties) && !this.tableProperties.isServerSidePaging) {
            if (currentPageItems) {
              const filterTotal = currentPageItems.reduce((sum, j) => sum + CommonService.validateNumber(j[cell.displayName]), 0);
              if (cell.fieldType == InputType.Amount) {
                this.footerDatasource[cell.displayName] = `${filterTotal.toFixed(2)} /${val.toFixed(2)} <i class="fa fa-inr color-primary" aria-hidden="true"></i>`;
              } else {
                this.footerDatasource[cell.displayName] = `${filterTotal} /${val}`;
              }
            } else {
              this.footerDatasource[cell.displayName] = '';
            }
          } else {
            if (cell.fieldType == InputType.Amount) {
              this.footerDatasource[cell.displayName] = `${val.toFixed(2)} /${this.tableFirstRow[cell.footerField].toFixed(2)} <i class="fa fa-inr color-primary" aria-hidden="true"></i>`;
            } else {
              this.footerDatasource[cell.displayName] = `${val} /${this.tableFirstRow[cell.footerField]}`;
            }
          }
        } else {
          this.footerDatasource[cell.displayName] = '';
        }
      });
      if (this.footerDisplay === true)
        this.footerDatasource[cellDefArr[0].displayName] = 'Total:';
    }
  }

  openDialog() {
    this.advanceSearchObject.prevSearch = this.clsfilter.filterArray;
    this.dialogRef = this.dialog.open(FilterGridComponent, {
      data: this.advanceSearchObject,
      maxHeight: '400px',
      width: '600px',
    });

    this.dialogRef.afterClosed().subscribe(result => {
      this.applyAdvanceFilter(result);
    });
  }

  private applyAdvanceFilter(result: any) {
    if (!isNullOrUndefined(result)) {
      if (!this.tableProperties.isServerSidePaging) {
        this.clearFilter();
        result.forEach((t: IHashTable) => {
          if (!isNullOrUndefined(t.key)) {
            this.filterObject[t.key] = t.value;
          }
        });
      }
      this.clsfilter.filterArray = result;
      this.sharedService.sharedMaster[this.tableProperties.pageEnum].searchFilter = this.clsfilter;
      if (result.length === 0) {
        this.clsfilter.searchValue = '';
        this.setFilterObject();
        if (this.tableProperties.isServerSidePaging)
          this.filter.emit({ filter: this.clsfilter });
      } else if (result.length === 1) {
        this.clsfilter.searchField = result[0].key;
        this.clsfilter.searchValue = result[0].value;
        this.onFilterChangeEvent(result[0].key);
        this.setFilterObject();
      } else if (this.tableProperties.isServerSidePaging) {
        this.filter.emit({ filter: this.clsfilter });
      } else if (!this.tableProperties.isServerSidePaging) {
        this.filterLocalEvent()
      }
    } else {
      this.clsfilter.searchValue = '';
      this.setFilterObject();
    }
  }

  private clearFilter() {
    this.displayedColumns.forEach(element => { this.filterObject[element] = ''; });
  }

  private filterLocalEvent() {
    this.tableSource.filter = JSON.stringify([(isNullOrUndefined(this.searchFieldDDL) ? [] : this.searchFieldDDL), this.filterObject]);
  }

  createFilter(): (data: any, filter: string) => boolean {
    let filterFunction = function (data, filter): boolean {
      let searchObject = JSON.parse(filter); // searchObject[0] searchFieldDDL 
      const searchTerms = searchObject[1];
      let tot = Object.values(searchTerms).every(x => (isNullOrUndefined(x) || String(x).trim() === ''));
      let hasArr = [];
      if (tot === false) {
        searchObject[0].forEach(t => {
          switch (t.fieldType) {
            case InputType.Date:
              if (!isNullOrUndefined(data[t.displayName]) && data[t.displayName].toString().trim() !== ''
                && !isNullOrUndefined(searchTerms[t.displayName]) && isDate(searchTerms[t.displayName + '_from']) && isDate(searchTerms[t.displayName + '_to'])) {
                hasArr.push((new Date(data[t.displayName]) >= new Date(searchTerms[t.displayName + '_from']) && new Date(data[t.displayName]) <= new Date(searchTerms[t.displayName + '_to'])));
              }
              break;
            default:
              if (!isNullOrUndefined(data[t.displayName]) && !isNullOrUndefined(searchTerms[t.displayName]) && searchTerms[t.displayName].toString().trim() !== '') {
                hasArr.push((data[t.displayName].toString().trim().toLowerCase().indexOf(searchTerms[t.displayName].trim().toLowerCase()) !== -1));
              } else if (isNullOrUndefined(data[t.displayName]) || data[t.displayName].toString().trim() === '') {
                hasArr.push(false);
                // if (!isNullOrUndefined(data[t.displayName]) && !isNullOrUndefined(searchTerms[t.displayName]) && searchTerms[t.displayName].toString().trim() !== '') {
                //   hasArr.push((data[t.displayName].toString().trim().toLowerCase().indexOf(searchTerms[t.displayName].trim().toLowerCase()) !== -1));
              }
              break;
          }
        });
      }
      return Object.values(hasArr).every(x => (x === true));
    }
    return filterFunction;
  }

  removeFilterObject(item) {
    if (!isNullOrUndefined(this.clsfilter.filterArray) && this.clsfilter.filterArray.length > 0) {
      if (this.chipDisplayObj[item.key].inputType === InputType.Date) {
        let fromKey = '';
        if (item.key.indexOf('_from') !== -1) {
          fromKey = item.key.replace('_from', '_to');
        } else {
          fromKey = item.key.replace('_to', '_from');
        }
        this.clsfilter.filterArray = this.clsfilter.filterArray.filter((t) => { if (t.key != item.key && t.key != fromKey) { return t; } });
      } else {
        this.clsfilter.filterArray = this.clsfilter.filterArray.filter((t) => { if (t.key != item.key) { return t; } });
      }
      this.applyAdvanceFilter(this.clsfilter.filterArray);
    }
  }

  updateObject(item) {
    if (!isNullOrUndefined(this.clsfilter.filterArray)) {
      if (!isNullOrUndefined(this.clsfilter.filterArray.find(t => t.key === item.key))) {
        this.clsfilter.filterArray = this.clsfilter.filterArray.filter((t) => { if (t.key == item.key) { t.value = item.value; return t; } });
      } else {
        this.clsfilter.filterArray.push(item);
      }
    }
  }

  ngOnDestroy(): void {
    if (!isNullOrUndefined(this.subscription)) {
      this.subscription.unsubscribe();
    }
    if (!isNullOrUndefined(this.watcher)) {
      this.watcher.unsubscribe();
    }
    if (!isNullOrUndefined(this.dialogRef)) {
      this.dialogRef.close();
    }
  }

}

export class TableFooter {
  constructor(private _columnName, private value) {
    this.columnName = _columnName;
    this.fieldvalue = value;
  }
  columnName: string;
  fieldvalue: string;
}

export class TableObject {
  constructor(private _cellDef: Array<cellDef>, private _actionButton: number, _isServerSidePaging: boolean, _defaultSearchField: string, _deaultFilter: CommonFilter = null, _pageEnum: VendorEnum, _showHistory: boolean = false) {
    this.cellDefArray = _cellDef;
    this.actionButton = _actionButton;
    this.isServerSidePaging = _isServerSidePaging;
    this.defaultSearchField = _defaultSearchField;
    this.deaultFilter = _deaultFilter;
    this.pageEnum = _pageEnum;
    this.showHistory = _showHistory;
  }
  cellDefArray: Array<cellDef>
  actionButton: number;
  isServerSidePaging: boolean;
  defaultSearchField: string;
  deaultFilter: CommonFilter;
  pageEnum: VendorEnum;
  showHistory: boolean;
}

export class cellDef {
  constructor(_displayName, _headerName, _showInFieldDDl, _fieldType, _footerField, _tooltipField, _cellCSS = '') {
    this.displayName = _displayName;
    this.headerName = _headerName;
    this.showInFieldDDl = _showInFieldDDl;
    this.fieldType = _fieldType;
    this.footerField = _footerField;
    this.tooltipField = _tooltipField
    this.cellCSS = _cellCSS;
  }
  displayName: string;
  headerName: string;
  showInFieldDDl: boolean;
  fieldType: InputType;
  footerField: string;
  tooltipField: TemplateRef<any>;
  cellCSS: string;
}

// export enum TableButtons {
//   Select = 1,
//   Add = 2,
//   Edit = 4,
//   Delete = 8,
//   Print = 32
// }
// onAction(selectedItem) {
//   this.pageProperties.selectedRow = selectedItem.data;
//   switch (selectedItem.actionButon) {
//     case TableButtons.View:
//       break;
//     case AccessLevel.New:
//       break;
//     case AccessLevel.Delete:
//       break;
//     case AccessLevel.Edit:
//       break;
//     case AccessLevel.Print:
//       break;
//     default:
//       break;
//   }
// }