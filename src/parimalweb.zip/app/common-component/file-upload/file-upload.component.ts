import { animate, state, style, transition, trigger } from '@angular/animations';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Component, ElementRef, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';

@Component({
  selector: 'app-file-upload',
  templateUrl: './file-upload.component.html',
  styleUrls: ['./file-upload.component.css'],
  animations: [
    trigger('shrinkOut', [
      state('in', style({})),
      transition('* => void', [
        style({ height: '!', opacity: 1 }),
        animate(600, style({ height: 0, opacity: 0 }))
      ]),
      transition('void => *', [
        style({ height: 0, opacity: 0 }),
        animate(700, style({ height: '*', opacity: 1 }))
      ])
    ])
  ]
})
export class FileUploadComponent implements OnInit {
  @Input() multiple = false;
  @Input() files: File[] = [];
  @Input() chooseLabel = 'Choose';
  @Input() uploadLabel = 'Upload';
  @Input() cancelLabel = 'Cancel';
  @Input() maxFileSize: number;
  @Input() showUpdateRemoveAll = false;
  @Input() httpUrl = '';
  @Input() acceptFormat = 'image/*,.pdf';
  @Input() invalidFileSizeMessageSummary: string;
  @Input() requestObject: any; // Eg: { poNo : 1 }
  @Input() userNote = '';
  // @Input() httpRequestParams: HttpParams | { [param: string]: string | string[]; } = new HttpParams();
  @Input() httpRequestHeaders: HttpHeaders | { [header: string]: string | string[]; } = new HttpHeaders().set("Content-Type", "multipart/form-data");
  @ViewChild('fileUpload', { static: true }) fileUpload: ElementRef;
  @Input() fileAlias: string = "file";
  @Output() onUploadCompleted = new EventEmitter();
  
  constructor(private sanitizer: DomSanitizer, private httpClient: HttpClient) { }

  ngOnInit() { }

  inputFileName: string;
  public loaded: number = 0;
  isUploadAll: boolean = false;
  onClick(event) {
    if (this.fileUpload)
      this.fileUpload.nativeElement.click()
  }

  onFileSelected(event) {
    let files = event.dataTransfer ? event.dataTransfer.files : event.target.files;
    console.log('event::::::', event)
    for (let i = 0; i < files.length; i++) {
      let file = files[i];
      if (this.validate(file)) {
        file.objectURL = this.sanitizer.bypassSecurityTrustUrl((window.URL.createObjectURL(files[i])));
        if (!this.isMultiple()) {
          this.files = []
        }
        this.files.unshift(files[i]);
      }
    }
  }

  validate(file: File) {
    for (const f of this.files) {
      if (f.name === file.name
        && f.lastModified === file.lastModified
        && f.size === f.size
        && f.type === f.type
      ) {
        return false
      }
    }
    return true
  }

  remove(index) {
    if (this.files)
      this.files.splice(index, 1);
  }

  isMultiple(): boolean {
    return this.multiple
  }

  uploadedFile(event) {
    this.onUploadCompleted.emit(event);
  }

  public uploadAll() {
    this.isUploadAll = true;
  }

  public removeAll() {
    this.files.splice(0, this.files.length);
  }

}
