import { APP_BASE_HREF } from '@angular/common';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { APP_INITIALIZER, NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { DateAdapter, MAT_DATE_FORMATS } from '@angular/material';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ServiceWorkerModule } from '@angular/service-worker';
import { NgProgressModule } from '@ngx-progressbar/core';
import { NgProgressRouterModule } from '@ngx-progressbar/router';
import { UserIdleModule } from 'angular-user-idle';
import { KeyboardShortcutsModule } from 'ng-keyboard-shortcuts';
import { environment } from '../environments/environment';
import { AppInitialize } from './app-init.service';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AuthGuard } from './auth/auth.guard';
import { AuthService } from './auth/auth.service';
import { TimeoutComponent } from './auth/timeout/timeout.component';
import { ConfirmationPopupComponent } from './common-component/confirmation-popup/confirmation-popup.component';
import { FilterGridComponent } from './common-component/filter-grid/filter-grid.component';
import { SnackbarComponentComponent } from './common-component/snackbar-component/snackbar-component.component';
import { HttpInterceptorService } from './common-services/http-interceptor.service';
import { IndianDateadapterService, MY_DATE_FORMATS } from './common-services/indian-dateadapter.service';
import { SnackBarService, HistoryService } from './common-services/snack-bar.service';
import { MenuListItemComponent } from './menu/app-menu-list-item/menu-list-item.component';
import { NavService } from './menu/menu-service/nav.service';
import { MenuComponent } from './menu/menu.component';
import { NotfoundComponent } from './notfound/notfound.component';
import { SharedModule } from './shared/shared.module';
import { SharedService } from './shared/shared.service';


export function get_settings(appInitService: AppInitialize) {
  return () => appInitService.getSettings(environment.congifURL);
}

@NgModule({
  declarations: [
    AppComponent,
    NotfoundComponent,
    MenuListItemComponent,
    MenuComponent,
    SnackbarComponentComponent,
    ConfirmationPopupComponent,
    TimeoutComponent,
    FilterGridComponent,


  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    SharedModule,
    AppRoutingModule,
    NgProgressModule,
    ReactiveFormsModule,
    HttpClientModule,
    NgProgressRouterModule,
    KeyboardShortcutsModule,

    UserIdleModule.forRoot({ idle: 150, timeout: 60, ping: 120 }),
    ServiceWorkerModule.register('/ngsw-worker.js', { enabled: environment.production }),
  ],
  providers: [NavService, AppInitialize, AuthGuard, AuthService, SnackBarService, SharedService, HistoryService,
    { provide: APP_BASE_HREF, useValue: '/' },
    { provide: HTTP_INTERCEPTORS, useClass: HttpInterceptorService, multi: true },
    { provide: APP_INITIALIZER, useFactory: get_settings, deps: [AppInitialize], multi: true },
    { provide: DateAdapter, useClass: IndianDateadapterService },
    { provide: MAT_DATE_FORMATS, useValue: MY_DATE_FORMATS }],
  entryComponents: [SnackbarComponentComponent, ConfirmationPopupComponent, TimeoutComponent, FilterGridComponent],
  bootstrap: [AppComponent]
})
export class AppModule { }
