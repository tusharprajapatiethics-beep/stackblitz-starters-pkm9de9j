import { IFilter, IHashTable } from "./interface.service";
import { CommonService } from "./common-functions.service";
import { isNullOrUndefined } from "util";
import { VendorEnum } from "./enum.service";

export class CommonFilter implements IFilter {
    constructor(_vendorCode: string, _currentPage: VendorEnum = VendorEnum.None) {
        this.pageNumber = 1;
        this.pageSize = 10;
        this.isExport = false;
        this.currentPage = _currentPage;
        // if (_companyId === 0) {
        //     this.companyId = CommonService.defaultComanyId;
        // } else {
        //     this.companyId = _companyId;
        // }
        // if (isNullOrUndefined(this.yearKey) && this.yearKey === 0) {
        //     this.yearKey = CommonService.defaultYearKey;
        // }
        // this.idOnly = false;
        this.filterArray = new Array<IHashTable>();
    }
    currentPage: VendorEnum;
    pageNumber: number;
    pageSize: number;
    isExport: boolean;
    fromDate: string;
    toDate: string;
    orderBy: string;
    searchField: string;
    searchValue: string;
    vendorCode: string;
    filterArray: Array<IHashTable>;
}

export class ApiResponse {
    status: boolean;
    message: string;
    data: any
}

export class StoreAdvanceSearch extends CommonFilter {
    Store_Name = '';
    Address = '';
    District = '';
    State = '';
    IsAllFilteredStoreSelect = false;
}

export class Documents {
    poNo = 0;
    documentPath = '';
    documentName = '';
    documentType = '';
    uploadDate = new Date();
    uploadBy = '';
    documentSize = '';
}

