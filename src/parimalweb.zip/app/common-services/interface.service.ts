import { ShortCutKeys,VendorEnum } from "./enum.service";
import { cellDef } from "../common-component/mat-table/mat-table.component";


export interface IFilter {
    fromDate: string;
    toDate: string;
    pageNumber: number;
    pageSize: number;
    orderBy: string;
}

export interface IDropdown {
    id: any;
    name: any;
}

export interface IShortCutKeys { key: ShortCutKeys, description: string }

export interface IFilterGridInput { searchCell: Array<cellDef>, pageEnum: VendorEnum, prevSearch: Array<IHashTable>, focusControl: string }

export interface IHashTable { key: string, value: any };
