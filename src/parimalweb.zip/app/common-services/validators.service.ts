import { AbstractControl, ValidatorFn, FormGroup, ValidationErrors } from '@angular/forms';
import * as libphonenumber from 'google-libphonenumber';
import { isNullOrUndefined } from 'util';
import { Logger, CommonService } from './common-functions.service';
import { strictEqual } from 'assert';

const phoneNumberUtil = libphonenumber.PhoneNumberUtil.getInstance();

export class ValidatorsService {

  static PhoneNumberValidator = (regionCode: string = 'IN'): ValidatorFn => {
    return (control: AbstractControl): { [key: string]: any } => {
      let validNumber = false;
      try {
        if (!isNullOrUndefined(control.value) && control.value.trim() !== '') {
          const phoneNumber = phoneNumberUtil.parseAndKeepRawInput(control.value, regionCode);
          validNumber = phoneNumberUtil.isValidNumber(phoneNumber);
        } else {
          return null;
        }
      } catch (e) {
        Logger.Warn(e);
      }
      return validNumber ? null : { 'wrongNumber': { value: control.value } };
    }
  };
}

export class FormServices {
  static focusFormValidationErrors(fg: FormGroup) {
    let keyName = '';
    Object.keys(fg.controls).forEach(key => {
      const controlErrors: ValidationErrors = fg.get(key).errors;
      if (controlErrors != null && keyName === '') {
        keyName = key;
        CommonService.focusControlById(keyName);
        Object.keys(controlErrors).forEach(keyError => {
          Logger.Warn('Key control: ' + key + ', keyError: ' + keyError + ', err value: ', controlErrors[keyError]);
        });
      }
    });
  }
}