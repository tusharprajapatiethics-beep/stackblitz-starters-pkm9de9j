import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { FormServices } from '../../common-services/validators.service';
import { AuthService } from '../auth.service';
import { CommonService } from '../../common-services/common-functions.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  successMessage: string;
  validationMessage = '';
  loading = false;
  loginForm: FormGroup;
  constructor(private router: Router,
    private route: ActivatedRoute,
    private authService: AuthService,
    private fg: FormBuilder) {
    this.loginForm = fg.group(
      {
        "userName": [null, [Validators.required]],
        "password": [null, [Validators.required, Validators.minLength(5)]]
      });
  }

  ngOnInit() {
    this.route.fragment.subscribe((fragment: string) => {
      if (fragment === 'sessionexpired') {
        this.validationMessage = 'Your session has expored due to inactivity'
      }
    });
    FormServices.focusFormValidationErrors(this.loginForm);
  }

  onLogin() {
    this.successMessage = '';
    if (this.loginForm.valid) {
      this.loading = true;
      this.authService.login(this.loginForm.value.userName, this.loginForm.value.password)
        .subscribe((data: any) => {
          // TODO: Need to update with dropdown
          // CommonService.defaultYearKey = 3;
          this.router.navigateByUrl('/');
          this.loading = false;
        }, (ex: any) => {
          if (ex.error !== undefined && ex.error.error === 'invalid_grant') {
            this.validationMessage = ex.error.error_description;
          } else {
            this.validationMessage = 'System Error: Please try after some time or Contact to support.';
          }
          this.loading = false;
        });
    } else {
      this.loginForm.markAsTouched();
      FormServices.focusFormValidationErrors(this.loginForm);
    }
  }
}
