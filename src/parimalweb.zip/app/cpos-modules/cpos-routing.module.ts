import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { TestMaterialControlComponent } from './test-material-control/test-material-control.component';
// ./dashboard/dashboard.module#DashbordModule
const routes: Routes = [
    { path: '', loadChildren: '../dashboard/dashboard.module#DashbordModule' },
    { path: 'example', component: TestMaterialControlComponent },
    { path: 'user', loadChildren: './admin/admin.module#AdminModule' },
    { path: 'master', loadChildren: './master/master.module#MasterModule' },
    { path: 'vp', loadChildren: './vendor/vendor.module#VendorModule' },
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule],
    declarations: [],
    providers: [],
})
export class CPOSRoutingModule { }
