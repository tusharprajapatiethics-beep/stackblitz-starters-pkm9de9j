import { Component, OnInit } from '@angular/core';
import { ObservableMedia } from '@angular/flex-layout';
import { MatTableDataSource } from '@angular/material';
import { ActivatedRoute, Router } from '@angular/router';
import { isNullOrUndefined } from 'util';
import { cellDef, TableObject } from '../../../common-component/mat-table/mat-table.component';
import { Logger } from '../../../common-services/common-functions.service';
import { AccessLevel, InputType, VendorEnum } from '../../../common-services/enum.service';
import { ExcelService } from '../../../common-services/excel.service';
import { CommonFilter } from '../../../common-services/models.service';
import { SnackBarService } from '../../../common-services/snack-bar.service';
import { FilterObject, SharedService } from '../../../shared/shared.service';
import { AdminService } from '../admin.service';

@Component({
  selector: 'app-user-list',
  templateUrl: './user-list.component.html',
  styleUrls: ['./user-list.component.css']
})
export class UserListComponent implements OnInit {
  pageProperties = {
    sectionHeight: 0,
    selectedRow: null,
    filter: null,
    newURL: `/cpos/admin/register/${btoa('0')}`,
  };
  dataSource = new MatTableDataSource<any>([]);
  tableObject: TableObject;

  constructor(private media: ObservableMedia,
    private notification: SnackBarService,
    private sharedService: SharedService,
    private router: Router,
    private route: ActivatedRoute,
    private excelService: ExcelService,
    private adminService: AdminService) {
    media.subscribe((t) => {
      this.ResizeEvent();
    });
  }

  ngOnInit() {
    this.route.data.subscribe((t) => {
      this.dataSource = new MatTableDataSource<any>(t.data[0].data);
      this.setDataSource = t.data[0].data;
    });
    this.pageProperties.filter = this.getFilter;
    this.tableObject = new TableObject([
      new cellDef('userId', 'No.', true, InputType.Number, '', ''),
      new cellDef('fullName', 'Name', false, InputType.Text, '', ''),
      new cellDef('gender', 'Gender', true, InputType.Text, '', ''),
      new cellDef('roleName', 'Role', true, InputType.Text, '', ''),
      new cellDef('email', 'Email', true, InputType.Text, '', ''),
      new cellDef('phoneNumber', 'Phone Number', true, InputType.Text, '', '')
    ], 6, false, '', this.getFilter, VendorEnum.User);
    this.ResizeEvent();
  }

  private ResizeEvent() {
    setTimeout(() => {
      this.pageProperties.sectionHeight = document.getElementById('mainSection').offsetHeight - 200;
    }, 100);
  }

  public get getFilter(): CommonFilter {
    if (isNullOrUndefined(this.sharedService.sharedMaster[VendorEnum.User])) {
      this.sharedService.sharedMaster[VendorEnum.User] = new FilterObject(new CommonFilter('', VendorEnum.User));
    }
    return this.sharedService.sharedMaster[VendorEnum.User].searchFilter;
  }

  public set saveFilter(v: any) {
    if (isNullOrUndefined(this.sharedService.sharedMaster[VendorEnum.User])) {
      this.sharedService.sharedMaster[VendorEnum.User] = new FilterObject(v);
    } else {
      this.sharedService.sharedMaster[VendorEnum.User].searchFilter = v;
    }
  }

  public set setDataSource(v: any) {
    if (isNullOrUndefined(this.sharedService.sharedMaster[VendorEnum.User])) {
      this.sharedService.sharedMaster[VendorEnum.User] = new FilterObject(this.getFilter, v);
    } else {
      this.sharedService.sharedMaster[VendorEnum.User].dataSource = v;
    }
  }

  onTableButtonAction(selectedItem) {
    this.pageProperties.selectedRow = selectedItem.data;
    this.adminService.selectedUser = selectedItem.data;
    switch (selectedItem.actionButon) {
      case AccessLevel.View:
        break;
      case AccessLevel.New:
        this.router.navigate([`user/register/${btoa('0')}`])
        break;
      case AccessLevel.Delete:
        if (this.sharedService.formBtn.actionAccess === 0) {
          this.onDelete();
        }
        break;
      case AccessLevel.Edit:
        this.router.navigate([`user/register/${btoa(this.pageProperties.selectedRow['userId'])}`])
        break;
      case AccessLevel.Print:
        break;
      default:
        break;
    }
  }

  onDelete() {
    if (!isNullOrUndefined(this.pageProperties.selectedRow) && this.pageProperties.selectedRow['userId'] > 0) {
      const dialogRef = this.sharedService.getConfirmatonConfig('Confirmation', `Are you sure want to delete '${this.pageProperties.selectedRow.trO_OWNER_NAME}'?`);
      dialogRef.afterClosed().subscribe(result => {
        if (!isNullOrUndefined(result) && result === true) {
          const param = this.pageProperties.selectedRow.userId;
          this.sharedService.customGetApi('account/delete?Id=' + this.pageProperties.selectedRow.userId).subscribe((t) => {
            const index = this.sharedService.sharedMaster[VendorEnum.User].dataSource.indexOf(this.pageProperties.selectedRow);
            this.sharedService.sharedMaster[VendorEnum.User].dataSource.splice(index, 1);
            this.dataSource = new MatTableDataSource<any>(this.sharedService.sharedMaster[VendorEnum.User].dataSource);
            this.pageProperties.selectedRow = null;
            this.notification.success('User deleted successfully.');
          }, (error) => {
            Logger.Error(error);
            this.notification.error('User delete Failed.');
          });
        }
      });
    } else {
      this.notification.error('Select atlease one User.');
    }
  }

  onFilterEvent(event) {
    // this.sharedService.sharedMaster[CPOSEnum.City].searchFilter = event.filter;
  }

}
