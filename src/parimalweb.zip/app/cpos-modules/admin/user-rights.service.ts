import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject } from 'rxjs';
import { share } from 'rxjs/operators';
import { isNullOrUndefined } from 'util';

@Injectable()
export class UserRightsService {

    /**
     * DataChange Object For Update Content of tree
     */
    dataChange = new BehaviorSubject<FileNode[]>([]);

    get data(): FileNode[] { return this.dataChange.value; }

    constructor(private http: HttpClient) {
        // this.dataChange.next(TREE_DATA3);
        // console.log(TREE_DATA3);
    }

    /**
     * GET DEFAULT RIGHTS PAGE DATA
     * CREATED BY PARIMAL VAGHASIYA
     */
    defaultUserRightsData(): any {
        return this.http.get<any[]>('rights/defaultdata');
    }

    /**
     * SAVE RIGHTS INFORMATION
     * CREATED BY PARIMAL VAGHASIYA
     * @param data 
     * @param role 
     * @param userId 
     */
    saveUserRights(data: any, role, userId) {
        // this.parseJson(data)
        const userRights = {
            roleName: role,
            userId: userId,
            rightsList: data,
        };
        return this.http.post<any>('rights/saveuserrights', userRights);
    }

    parseJson(o) {
        const cache = [];
        o.forEach(t => {
            cache.push(t)
            if (!isNullOrUndefined(t.children) && t.children.length > 0) {
                t.children.forEach(element => {
                    cache.push(element)
                });
            }
        });
        return cache;
    }

    /**
     * GET RIGHTS TREE BASED ON ROLE AND USER_ID
     * CREATED BY PARIMAL VAGHASIYA
     * @param userId 
     * @param role 
     */
    getUserRightsTree(userId: any, role: any, isTree = true): any {
        return this.http.get<any[]>(`rights/getrightstree?userId=${userId}&role=${role}&isTree=${isTree}`).pipe(share());
    }

    getMenuTree(): any {
        return this.http.get<any[]>(`rights/menutree`);
    }

}

/**
 * File node data with nested structure.
 * Each node has a filename, and a type or a list of children.
 */
export class FileNode {
    /**
     *
     */
    constructor() {
        this.children = new Array<FileNode>();
    }
    children: FileNode[];
    type: any;
    id: number;
    parentId: number;
    home: boolean;
    icon: string;
    link: string;
    title: string;
    userAccessLevel: 0
}

/** Flat node with expandable and level information */
export class FileFlatNode {
    constructor(
        public expandable: boolean,
        public level: number,
        public type: any,
        public id: number,
        public parentId: number,
        public title: string,
        public link: string,
        public userAccessLevel: number,
        public home: boolean) { }
}

// const TREE_DATA3 = [
//     {
//         "id": 2, "parentId": 0, "title": "Dashboard", "link": null, "icon": "fa fa-star", "home": null, "userAccessLevel": 0, children: [{ "id": 1, "parentId": 0, "title": "Dashboard", "link": "./user/dashboard", "icon": "fa fa-home", "home": true, "userAccessLevel": 0 }]
//     },
//     {
//         "id": 2, "parentId": 0, "title": "Admin", "link": null, "icon": "fa fa-star", "home": null, "userAccessLevel": 0, children: [
//             { "id": 2, "parentId": 0, "title": "Admin", "link": null, "icon": "fa fa-star", "home": null, "userAccessLevel": 0 },
//             { "id": 3, "parentId": 2, "title": "User List", "link": "./user/list", "icon": null, "home": null, "userAccessLevel": 0 },
//             { "id": 4, "parentId": 2, "title": "Role Rights", "link": "./user/rights/1", "icon": null, "home": null, "userAccessLevel": 0 },
//             { "id": 5, "parentId": 2, "title": "User Rights", "link": "./user/rights/2", "icon": null, "home": null, "userAccessLevel": 0 }
//         ]
//     },
//     {
//         "id": 2, "parentId": 0, "title": "Admin", "link": null, "icon": "fa fa-star", "home": null, "userAccessLevel": 0, children: [
//             { "id": 2, "parentId": 0, "title": "Admin", "link": null, "icon": "fa fa-star", "home": null, "userAccessLevel": 0 },
//             { "id": 3, "parentId": 2, "title": "User List", "link": "./user/list", "icon": null, "home": null, "userAccessLevel": 0 },
//             { "id": 4, "parentId": 2, "title": "Role Rights", "link": "./user/rights/1", "icon": null, "home": null, "userAccessLevel": 0 },
//             { "id": 5, "parentId": 2, "title": "User Rights", "link": "./user/rights/2", "icon": null, "home": null, "userAccessLevel": 0 }
//         ]
//     },
//     {
//         "id": 2, "parentId": 0, "title": "Admin", "link": null, "icon": "fa fa-star", "home": null, "userAccessLevel": 0, children: [
//             { "id": 2, "parentId": 0, "title": "Admin", "link": null, "icon": "fa fa-star", "home": null, "userAccessLevel": 0 },
//             { "id": 3, "parentId": 2, "title": "User List", "link": "./user/list", "icon": null, "home": null, "userAccessLevel": 0 },
//             { "id": 4, "parentId": 2, "title": "Role Rights", "link": "./user/rights/1", "icon": null, "home": null, "userAccessLevel": 0 },
//             { "id": 5, "parentId": 2, "title": "User Rights", "link": "./user/rights/2", "icon": null, "home": null, "userAccessLevel": 0 }
//         ]
//     },
//     {
//         "id": 2, "parentId": 0, "title": "Admin", "link": null, "icon": "fa fa-star", "home": null, "userAccessLevel": 0, children: []
//     }
// ] as FileNode[];
