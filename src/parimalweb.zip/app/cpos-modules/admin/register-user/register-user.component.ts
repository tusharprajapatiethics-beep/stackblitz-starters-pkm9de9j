import { Component, OnInit, ViewChild, ContentChild } from '@angular/core';
import { ObservableMedia } from '@angular/flex-layout';
import { AbstractControl, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { map, startWith } from 'rxjs/operators';
import { isNullOrUndefined } from 'util';
import { CommonService } from '../../../common-services/common-functions.service';
import { SnackBarService } from '../../../common-services/snack-bar.service';
import { SharedService } from '../../../shared/shared.service';
import { AdminService } from '../admin.service';
import { VendorEnum } from '../../../common-services/enum.service';

@Component({
  selector: 'app-register-user',
  templateUrl: './register-user.component.html',
  styleUrls: ['./register-user.component.css']
})
export class RegisterUserComponent implements OnInit {

  user: RegisterModel;
  registrationForm: FormGroup;
  // @ContentChild("matAutocomplete", { static: false }) matAutocomplete: MatAutocomplete;
  pageProperties = {
    userId: 0,
    selectedUser: null,
    tempUser: null
  };
  vendorList = [];
  vendorOptions: Observable<any[]>;

  constructor(private fb: FormBuilder, private router: Router,
    private route: ActivatedRoute, private notification: SnackBarService,
    public sharedService: SharedService, private media: ObservableMedia,
    private adminService: AdminService, public dialog: MatDialog) {
    this.route.params.subscribe((t) => {
      this.pageProperties.userId = Number(atob(t.id));
    });
  }

  ngOnInit() {
    this.route.data.subscribe((t) => {
      if (t && t.data && t.data.data) {
        this.vendorList = t.data.data;
      }
      this.pageProperties.selectedUser = this.adminService.selectedUser;
      this.pageProperties.tempUser = CommonService.copyObject(this.pageProperties.selectedUser);
      this.bindForm();
    });

    this.vendorOptions = this.registrationForm.controls['vendorCode'].valueChanges
      .pipe(
        startWith(''),
        map(value => typeof value === 'string' ? value : value.name),
        map(name => name ? this._filter(name) : this.vendorList.slice())
      );
  }

  displayFn(item) {
    return this.vendorList.filter(x => x.vendorCode === item).map(x => x.vendorName)[0] ? this.vendorList.filter(x => x.vendorCode === item).map(x => x.vendorName)[0] : null;
  }

  private bindForm() {
    if (this.pageProperties.userId === 0) {
      this.registrationForm = this.fb.group({
        'firstName': [null, [Validators.required]],
        'middleName': [null],
        'lastName': [null, [Validators.required]],
        'gender': [null],
        'roleName': [null, [Validators.required]],
        'email': [null, Validators.compose([Validators.required, Validators.email]), this.validateEmailNotTaken.bind(this)],
        'phoneNumber': [null, Validators.compose([Validators.pattern(CommonService.regExPatern.mobilePattern)])],
        'isActive': [true],
        'username': [null, [Validators.required], this.validateUserNameNotTaken.bind(this)],
        'password': [null, Validators.compose([Validators.required, PasswordValidator.strong])],
        'confirmPassword': [null, [Validators.required]],
        'canApprovePO': [false],
        'canApprovePlanningDelivery': [false],
        'canASNDeliveryApproval': [false],
        'canASNBPPIApproval': [false],
        'canASNVendorApproval': [false],
        'vendorCode': [null],

      }, { validator: this.checkIfMatchingPasswords('password', 'confirmPassword') });
    } else {
      const isnl = !isNullOrUndefined(this.pageProperties.selectedUser);
      const obj = this.pageProperties.selectedUser;
      this.registrationForm = this.fb.group({
        'firstName': [(isnl ? obj.firstName : null), [Validators.required]],
        'middleName': [(isnl ? obj.middleName : null)],
        'lastName': [(isnl ? obj.lastName : null), [Validators.required]],
        'gender': [(isnl ? obj.gender : null)],
        'roleName': [(isnl ? obj.roleName : null), [Validators.required]],
        'email': [(isnl ? obj.email : null), Validators.compose([Validators.required, Validators.email]), this.validateEmailNotTaken.bind(this)],
        'username': [{ value: (isnl ? obj.username : null), disabled: true }],
        'phoneNumber': [(isnl ? obj.phoneNumber : null), Validators.compose([Validators.pattern(CommonService.regExPatern.mobilePattern)])],
        'isActive': [(isnl ? obj.isActive : null)],
        'canApprovePO': [obj.canApprovePO],
        'canApprovePlanningDelivery': [obj.canApprovePlanningDelivery],
        'canASNDeliveryApproval': [obj.canASNDeliveryApproval],
        'canASNBPPIApproval': [obj.canASNBPPIApproval],
        'canASNVendorApproval': [obj.canASNVendorApproval],
        'vendorCode': [obj.vendorCode],
      });
    }

    this.registrationForm.controls['roleName'].valueChanges.subscribe((t) => {
      this.roleWisePermission(t);
    });
  }

  private _filter(name: string): any[] {
    const filterValue = name.toLowerCase();
    return this.vendorList.filter(option => option.name.toLowerCase().indexOf(filterValue) === 0);
  }

  validateUserNameNotTaken(control: AbstractControl) {
    const usename = this.pageProperties.userId > 0 ? this.pageProperties.tempUser.username : '';
    if (!isNullOrUndefined(control.value) && (this.pageProperties.userId === 0 || usename.toLowerCase() !== control.value.toLowerCase())) {
      const res = this.sharedService.sharedMaster[VendorEnum.User].dataSource.find(t => t.username.toLowerCase() === control.value.toLowerCase());
      return Observable.of(((!isNullOrUndefined(res)) ? { taken: true } : null));
    } else {
      return Observable.of(null);
    }
  }

  validateEmailNotTaken(control: AbstractControl) {
    const email = this.pageProperties.userId > 0 ? this.pageProperties.tempUser.email : '';
    if (!isNullOrUndefined(control.value) && (this.pageProperties.userId === 0 || email.toLowerCase() !== control.value.toLowerCase())) {
      const res = this.sharedService.sharedMaster[VendorEnum.User].dataSource.find(t => t.email.toLowerCase() === control.value.toLowerCase());
      return Observable.of(((!isNullOrUndefined(res)) ? { taken: true } : null));
    } else {
      return Observable.of(null);
    }
  }

  checkIfMatchingPasswords(passwordKey: string, passwordConfirmationKey: string) {
    return (group: FormGroup) => {
      const passwordInput = group.controls[passwordKey],
        passwordConfirmationInput = group.controls[passwordConfirmationKey];
      if (passwordInput.value !== passwordConfirmationInput.value) {
        return passwordConfirmationInput.setErrors({ notEquivalent: true });
      } else {
        return passwordConfirmationInput.setErrors(null);
      }
    };
  }

  onSubmit() {
    if (this.registrationForm.valid) {
      const saveObj = this.registrationForm.value;
      saveObj.userId = this.pageProperties.userId;
      if (saveObj.userId > 0) {
        saveObj.id = this.pageProperties.selectedUser.id;
        this.sharedService.customPostApi('account/update', saveObj).subscribe((t) => {
          if (t.status === true) {
            this.notification.success('Record Updated Successfully');
          } else {
            this.notification.warning(t.message === '' ? 'Something went wrong' : t.message);
          }
        });
      } else {
        this.sharedService.save(VendorEnum.User, saveObj).subscribe((t) => {
          if (t.status === true) {
            this.notification.success('Record Inserted Successfully');
            this.router.navigate([`user/register/${btoa(t.data['userId'])}`]);
          } else {
            this.notification.warning(t.message === '' ? 'Something went wrong' : t.message);
          }
        });
      }
    }
  }

  roleWisePermission(val) {
    this.registrationForm.controls['canApprovePO'].enable();
    this.registrationForm.controls['canApprovePlanningDelivery'].enable();
    this.registrationForm.controls['canASNDeliveryApproval'].enable();
    this.registrationForm.controls['canASNBPPIApproval'].enable();
    this.registrationForm.controls['canASNVendorApproval'].enable();
    this.registrationForm.controls['vendorCode'].setValue(null);
    this.registrationForm.controls['vendorCode'].setValidators(null);
    switch (val) {
      case 'SuperAdmin':
      case 'Admin':
        this.registrationForm.controls['canApprovePO'].setValue(false);
        this.registrationForm.controls['canApprovePlanningDelivery'].setValue(false);
        this.registrationForm.controls['canASNDeliveryApproval'].setValue(false);
        this.registrationForm.controls['canASNBPPIApproval'].setValue(false);
        this.registrationForm.controls['canASNVendorApproval'].setValue(false);
        break;
      case 'User':
        this.registrationForm.controls['canApprovePO'].setValue(false);
        this.registrationForm.controls['canApprovePO'].disable();
        this.registrationForm.controls['canApprovePlanningDelivery'].setValue(false);
        this.registrationForm.controls['canApprovePlanningDelivery'].disable();
        this.registrationForm.controls['canASNDeliveryApproval'].setValue(false);
        this.registrationForm.controls['canASNDeliveryApproval'].disable();
        this.registrationForm.controls['canASNBPPIApproval'].setValue(false);
        this.registrationForm.controls['canASNBPPIApproval'].disable();
        this.registrationForm.controls['canASNVendorApproval'].setValue(false);
        this.registrationForm.controls['canASNVendorApproval'].disable();
        break;
      case 'Vendor':
        this.registrationForm.controls['canApprovePO'].setValue(false);
        this.registrationForm.controls['canApprovePlanningDelivery'].setValue(false);
        this.registrationForm.controls['canApprovePlanningDelivery'].disable();
        this.registrationForm.controls['canASNDeliveryApproval'].setValue(false);
        this.registrationForm.controls['canASNDeliveryApproval'].disable();
        this.registrationForm.controls['canASNBPPIApproval'].setValue(false);
        this.registrationForm.controls['canASNBPPIApproval'].disable();
        this.registrationForm.controls['canASNVendorApproval'].setValue(false);
        this.registrationForm.controls['vendorCode'].setValidators([Validators.required]);
        break;
      case 'BPPI':
        this.registrationForm.controls['canApprovePO'].setValue(false);
        this.registrationForm.controls['canApprovePO'].disable();
        this.registrationForm.controls['canApprovePlanningDelivery'].setValue(false);
        this.registrationForm.controls['canASNDeliveryApproval'].setValue(false);
        this.registrationForm.controls['canASNBPPIApproval'].setValue(false);
        this.registrationForm.controls['canASNVendorApproval'].setValue(false);
        this.registrationForm.controls['canASNVendorApproval'].disable();
        break;
      case 'Ethics':
        this.registrationForm.controls['canApprovePO'].setValue(false);
        this.registrationForm.controls['canApprovePO'].disable();
        this.registrationForm.controls['canApprovePlanningDelivery'].setValue(false);
        this.registrationForm.controls['canASNDeliveryApproval'].setValue(false);
        this.registrationForm.controls['canASNBPPIApproval'].setValue(false);
        this.registrationForm.controls['canASNVendorApproval'].setValue(false);
        this.registrationForm.controls['canASNBPPIApproval'].disable();
        this.registrationForm.controls['canASNVendorApproval'].disable();
        break;
    }
  }


  onCancel() {
    if (this.pageProperties.userId === 0) {
      this.registrationForm.reset();
    } else {
      this.pageProperties.selectedUser = CommonService.copyObject(this.pageProperties.tempUser);
      this.bindForm();
    }
  }
}

export class RegisterModel {
  name: string;
  email: string;
  password: string
}
export class PasswordValidator {

  public static strong(control: FormControl): ValidationResult {
    // const hasNumber = /\d/.test(control.value);
    // const hasUpper = /[A-Z]/.test(control.value);
    // const hasLower = /[a-z]/.test(control.value);
    const valid = /(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&].{8,}/.test(control.value);
    // new RegExp('(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&].{8,}').test(control.value);
    // const pwdLength = control.value.length;
    // console.log('Num, Upp, Low', hasNumber, hasUpper, hasLower);
    // const valid = hasNumber && hasUpper && hasLower && pwdLength >= 6;
    if (!valid) {
      // return what´s not valid
      return { strong: true };
    }
    return null;
  }
}
export interface ValidationResult {
  [key: string]: boolean;
}





  // onRemoveStore(item): void {
  //   if (this.selectedStore.length > 0) {
  //     this.selectedStore = this.selectedStore.filter((t) => {
  //       if (t.store_Id !== item.store_Id) {
  //         return t;
  //       }
  //     });
  //   }
  // }

  // openDialog(): void {
  //   let objWidth = CommonService.getControlSizeById('mainSection');
  //   objWidth = objWidth.width > 0 ? `${((objWidth.width / 2) + 200)}px` : '600px'
  //   const dialogRef = this.dialog.open(AssignStoreComponent, {
  //     disableClose: true,
  //     width: objWidth,
  //     data: { popupWidth: objWidth, assignStores: this.selectedStore }
  //   });

  //   dialogRef.afterClosed().subscribe(result => {
  //     console.log('The dialog was closed');
  //     // this.animal = result;
  //   });
  // }
  