import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from '../../auth/auth.guard';
import { SharedModule } from '../../shared/shared.module';
import { AdminResolver } from './admin.resolver';
import { AdminService } from './admin.service';
import { RegisterUserComponent } from './register-user/register-user.component';
import { UserListComponent } from './user-list/user-list.component';
import { UserRightsService } from './user-rights.service';
import { UserRightsComponent } from './user-rights/user-rights.component';
import { VendorEnum } from '../../common-services/enum.service';

const routes: Routes = [
    {
        path: 'register/:id',
        component: RegisterUserComponent,
        canActivate: [AuthGuard],
        resolve: { data: AdminResolver },
        data: { dataFor: VendorEnum.UserRegistration, rights: '{ "0": 3 }' },
    },
    {
        path: 'list',
        component: UserListComponent,
        canActivate: [AuthGuard],
        resolve: { data: AdminResolver },
        data: { dataFor: VendorEnum.User, rights: '{ "0": 3 }' },
    },
    {
        path: 'rights/:type',
        component: UserRightsComponent,
        canActivate: [AuthGuard],
        resolve: { data: AdminResolver },
        data: { dataFor: VendorEnum.UserRights, rights: '{ "1": 4, "2": 5 }' },
    },
]

@NgModule({
    imports: [SharedModule, RouterModule.forChild(routes)],
    exports: [],
    declarations: [
        RegisterUserComponent,
        UserRightsComponent,
        UserListComponent,
    ],
    providers: [AdminService, AdminResolver, UserRightsService],
    entryComponents: []
})
export class AdminModule { }