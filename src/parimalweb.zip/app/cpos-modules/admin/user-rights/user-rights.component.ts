import { FlatTreeControl } from '@angular/cdk/tree';
import { Component, ContentChild, OnInit, ViewEncapsulation } from '@angular/core';
import { ObservableMedia } from '@angular/flex-layout';
import { MatDialog, MatSelect, MatTreeFlatDataSource, MatTreeFlattener } from '@angular/material';
import { ActivatedRoute } from '@angular/router';
import { isNullOrUndefined } from 'util';
import { AuthService } from '../../../auth/auth.service';
import { ConfirmationModel, ConfirmationPopupComponent } from '../../../common-component/confirmation-popup/confirmation-popup.component';
import { Logger } from '../../../common-services/common-functions.service';
import { SnackBarService } from '../../../common-services/snack-bar.service';
import { FileFlatNode, FileNode, UserRightsService } from '../user-rights.service';
import { ConfirmationHeader } from '../../../common-services/enum.service';

export interface Pokemon {
  value: string;
  lable: string;
}

export interface UserRole {
  disabled?: boolean;
  name: string;
  users: Pokemon[];
}

@Component({
  selector: 'app-user-rights',
  templateUrl: './user-rights.component.html',
  styleUrls: ['./user-rights.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class UserRightsComponent implements OnInit {

  treeControl: FlatTreeControl<FileFlatNode>;
  treeFlattener: MatTreeFlattener<FileNode, FileFlatNode>;
  dataSource: MatTreeFlatDataSource<FileNode, FileFlatNode>;
  @ContentChild("roleDDL", { static: false }) vcRole: MatSelect;
  @ContentChild("userDDL", { static: false }) vcUser: MatSelect;
  pageProperties = {
    sectionHeight: 0,
    selectedUser: null,
    currentSelection: 0,
    selectedRole: null
  }

  pageArrays = {
    accessLevel: [],
    userRoles: new Array<UserRole>()
  }

  pageNumber = {
    totalAccessLevel: 0
  };

  constructor(private userRightService: UserRightsService, private media: ObservableMedia,
    private activateRoute: ActivatedRoute,
    private authService: AuthService,
    public dialog: MatDialog,
    private notification: SnackBarService) {
    this.treeFlattener = new MatTreeFlattener(this.transformer, this._getLevel,
      this._isExpandable, this._getChildren);
    this.treeControl = new FlatTreeControl<FileFlatNode>(this._getLevel, this._isExpandable);
    this.dataSource = new MatTreeFlatDataSource(this.treeControl, this.treeFlattener);
    userRightService.dataChange.subscribe(data => this.dataSource.data = data);

    media.subscribe((t) => {
      this.ResizeEvent();
    });
  }

  private ResizeEvent() {
    setTimeout(() => {
      this.pageProperties.sectionHeight = document.getElementById('mainSection').offsetHeight - 230;
    }, 100);
  }

  transformer = (node: FileNode, level: number) => {
    return new FileFlatNode(!!node.children, level, node.type, node.id, node.parentId, node.title, node.link, node.userAccessLevel, node.home);
  }

  private _getLevel = (node: FileFlatNode) => node.level;

  private _isExpandable = (node: FileFlatNode) => node.expandable;

  private _getChildren = (node: FileNode): FileNode[] => node.children;

  hasChild = (_: number, _nodeData: FileFlatNode) => _nodeData.expandable;

  ngOnInit() {

    this.pageProperties.selectedUser = null;
    this.activateRoute.params.subscribe((t: any) => {
      if (!isNullOrUndefined(t)) {
        this.pageProperties.currentSelection = Number(t.type);
        // PARAM TYPE: 1 --> Role
        // PARAM TYPE: 2 --> User
        if (this.pageProperties.currentSelection === 1) {
          this.pageProperties.selectedUser = null;
        } else {
          this.pageProperties.selectedRole = null;
        }
      }
    });

    this.activateRoute.data.subscribe((resp) => {
      this.pageArrays.userRoles = resp.data.data.userRoleList as UserRole[];
      this.pageArrays.accessLevel = [];
      this.pageArrays.accessLevel.push({ id: 0, name: 'All' });
      this.pageArrays.accessLevel.push(...resp.data.data.accessList);
      setTimeout(() => {
        this.dataSource.data = <FileNode[]>resp.data.data.rightsList;
      }, 500);
      // this.userRightService.dataChange.next(<FileNode[]>resp.data.data.rightsList);
      this.focusControl();
    }, (error) => {
      console.log(error);
    });
  }

  private focusControl() {
    setTimeout(() => {
      if (this.pageProperties.currentSelection === 1 && this.vcRole) {
        this.vcRole.focused = this.pageProperties.currentSelection === 1;
      }
      else if (this.vcUser) {
        this.vcUser.focused = this.pageProperties.currentSelection === 2;
      }
    }, 100);
  }

  onAllCheckChangeEvent(e, rowData) {
    rowData.userAccessLevel = (e.checked) ? this.totalAccessLevel : 0;
  }

  onCheckChangeEvent(e, rowData, accessType) {
    if (accessType === 0) {
      this.onAllCheckChangeEvent(e, rowData);
    } else {
      if (!isNullOrUndefined(rowData) && !isNullOrUndefined(accessType)) {
        if (e.checked) {
          rowData.userAccessLevel = rowData.userAccessLevel + accessType;
        } else {
          rowData.userAccessLevel = rowData.userAccessLevel - accessType;
        }
      }
    }
  }

  getRightsList(userId, role) {
    this.userRightService.getUserRightsTree(userId, role).subscribe((t) => {
      // Logger.Normal(t.data);
      this.userRightService.dataChange.next(<FileNode[]>t.data);
    });
  }

  onRoleChange(event) {
    this.getRightsList(0, this.pageProperties.selectedRole);
  }

  onUserChange() {
    this.getRightsList(this.pageProperties.selectedUser.userId, this.pageProperties.selectedUser.roleName);
  }

  checkRight(accessType, accessLevel) {
    if (!isNullOrUndefined(accessType) && !isNullOrUndefined(accessLevel)) {
      if (accessType === 0) {
        return accessLevel === this.totalAccessLevel ? 0 : 1;
      } else {
        return (accessType & accessLevel)
      }
    } else {
      return null;
    }
  }

  public get totalAccessLevel(): number {
    if (isNullOrUndefined(this.pageNumber.totalAccessLevel) || this.pageNumber.totalAccessLevel <= 0) {
      this.pageArrays.accessLevel.forEach((t: any) => {
        this.pageNumber.totalAccessLevel = this.pageNumber.totalAccessLevel + t.id;
      });
    }
    return this.pageNumber.totalAccessLevel;
  }

  get checkValidation() {
    if (this.pageProperties.currentSelection === 1 && isNullOrUndefined(this.pageProperties.selectedRole)) {
      return false;
    } else if (this.pageProperties.currentSelection === 2 && isNullOrUndefined(this.pageProperties.selectedUser)) {
      return false;
    } else {
      return true;
    }
  }

  onSubmit() {

    if (this.checkValidation) {
      let Message = '';
      if (!isNullOrUndefined(this.pageProperties.selectedUser)) {
        Message = `Are you sure want to save rights for User ${this.pageProperties.selectedUser.fullName}`;
      } else {
        Message = `Are you sure want to save rights for role ${this.pageProperties.selectedRole}. ?`
      }
      this.askConfirmaton(ConfirmationHeader.Confirmation, Message, 'save');
    }
  }

  onReset() {
    if (!isNullOrUndefined(this.pageProperties.selectedUser)) {
      this.askConfirmaton(ConfirmationHeader.Confirmation, `Are you sure want to reset rights for User ${this.pageProperties.selectedUser.fullName}`, 'reset');
    }
  }

  askConfirmaton(header: ConfirmationHeader, message, operation) {
    const dialogRef = this.dialog.open(ConfirmationPopupComponent, {
      width: '400px',
      data: new ConfirmationModel(header, message),
      disableClose: true,
      closeOnNavigation: true
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log(result);
      if (!isNullOrUndefined(result)) {
        switch (operation) {
          case 'save':
            {
              this.saveUserRights();
              break;
            }
          case 'reset': {
            this.getRightsList(0, this.pageProperties.selectedUser.roleName);
          }
          default:
            break;
        }
      }
    });

  }

  private saveUserRights() {
    // this.pageProperties.validationMessage.message ='';
    this.userRightService.saveUserRights(this.dataSource._flattenedData.value, this.pageProperties.selectedRole
      , (isNullOrUndefined(this.pageProperties.selectedUser) ? 0 : this.pageProperties.selectedUser.userId)).subscribe((t) => {
        Logger.Normal(t);
        this.notification.success('Rights saved successfully', 'User Permission');
      }, (error) => {
        this.notification.error('Rights save failed', 'User Permission');
        console.error(error);
      });
  }

  onCancel() {
    if (this.pageProperties.currentSelection === 1 && !isNullOrUndefined(this.pageProperties.selectedRole)) {
      this.onRoleChange(null);
    } else if (this.pageProperties.currentSelection === 2 && !isNullOrUndefined(this.pageProperties.selectedUser)) {
      this.onUserChange();
    }
  }
}
