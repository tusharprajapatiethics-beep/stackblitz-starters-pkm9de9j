import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, Resolve, RouterStateSnapshot } from '@angular/router';
import { forkJoin } from 'rxjs';
import { Observable } from 'rxjs/Observable';
import { isNullOrUndefined } from 'util';
import { AuthService } from '../../auth/auth.service';
import { AdminService } from './admin.service';
import { UserRightsService } from './user-rights.service';
import { SharedService } from '../../shared/shared.service';
import { VendorEnum } from '../../common-services/enum.service';

@Injectable()
export class AdminResolver implements Resolve<any> {
    constructor(private adminService: AdminService,
        private authService: AuthService,
        private userRightService: UserRightsService,
        private sharedService: SharedService) {
    }
    resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<any[]> {

        const currentUrl = route.data['dataFor'];
        if (!isNaN(Number(currentUrl))) {
            switch (currentUrl) {
                case VendorEnum.User:
                    {
                        let response1 = this.adminService.getUserList();
                        return forkJoin([response1]);
                    }
                case VendorEnum.UserRegistration:
                    {
                        const id = Number(atob(route.paramMap.get('id')));
                        if (isNullOrUndefined(id) || id === 0) {
                            this.adminService.selectedUser = null;
                        }
                        return this.sharedService.getList(VendorEnum.Vendor, ''); // Get Vendor List
                    }
                case VendorEnum.UserRights: {
                    return this.userRightService.defaultUserRightsData().map(t => t);
                }
            }
        }
        return null;
    }
}
