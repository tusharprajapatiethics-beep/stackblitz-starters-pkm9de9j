import { NgModule } from '@angular/core';
import { ExcelService } from '../common-services/excel.service';
import { SharedModule } from '../shared/shared.module';
import { CPOSRoutingModule } from './cpos-routing.module';
import { CPOSService } from './cpos.service';
import { TestMaterialControlComponent } from './test-material-control/test-material-control.component';


@NgModule({
  imports: [
    SharedModule,
    CPOSRoutingModule,
  ],
  declarations: [TestMaterialControlComponent],
  providers: [CPOSService, ExcelService]
})
export class CPOSModule {

}
