import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-test-material-control',
  templateUrl: './test-material-control.component.html',
  styleUrls: ['./test-material-control.component.css']
})
export class TestMaterialControlComponent implements OnInit {
  constructor() { } 
  ngOnInit() {
  }
}
