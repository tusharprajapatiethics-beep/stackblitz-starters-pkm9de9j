import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, Resolve, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { AuthService } from '../../auth/auth.service';
import { SharedService } from '../../shared/shared.service';
import { MasterService } from './master.service';

@Injectable()
export class MasterResolver implements Resolve<any> {
    // filter = new CommonFilter();
    batchNoparam: any;
    constructor(private masterService: MasterService, private authService: AuthService, private sharedService: SharedService) {
        // this.filter.pageNumber = 1;
        // this.filter.pageSize = this.authService.AppConfig.gridItemsPerPage;
    }

    resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<any[]> {
        const currentUrl = route.data['dataFor'];
        if (!isNaN(Number(currentUrl))) {
            // switch (currentUrl) {
            // case CPOSEnum.City: {
            //     let response1 = this.sharedService.getList(Number(currentUrl));
            //     let response2 = this.sharedService.getDropdownList(CPOSEnum.State);
            //     return forkJoin([response1, response2]);
            // }
            // default:
            //     return this.sharedService.getList(Number(currentUrl));
            return null
            // }
        } else if (currentUrl.startsWith('city')) {
            return null;
        }
    }
}

  // if (Number(currentUrl) === MastersEnum.Company) {
            //     let response1 = this.masterService.getList(Number(currentUrl));
            //     let response2 = this.sharedService.getDropdownList(MastersEnum.State);
            //     return forkJoin([response1, response2]);
            // }
            // else if (Number(currentUrl) === MastersEnum.City) {
            //     let response1 = this.masterService.getList(Number(currentUrl));
            //     let response2 = this.sharedService.getDropdownList(MastersEnum.State);
            //     return forkJoin([response1, response2]);
            // } else if (Number(currentUrl) === MastersEnum.Marfatia) {
            //     if (!isNullOrUndefined(this.sharedService.sharedMaster[MastersEnum.Marfatia].searchFilter)) {
            //         this.filter = this.sharedService.sharedMaster[MastersEnum.Marfatia].searchFilter;
            //     }
            //     let response1 = this.masterService.filter(Number(currentUrl), this.filter);
            //     let response2 = this.sharedService.getDropdownList(MastersEnum.State);
            //     return forkJoin([response1, response2]);
            // } else {
            //     return this.masterService.getList(Number(currentUrl));
            // }
