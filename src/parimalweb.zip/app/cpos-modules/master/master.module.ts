import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from '../../shared/shared.module';
import { MasterResolver } from './master.resolver';
import { MasterService } from './master.service';

const routes: Routes = [
  // {
  //   path: 'state',
  //   component: StateComponent,
  //   resolve: { data: MasterResolver },
  //   canActivate: [AuthGuard],
  //   data: { dataFor: CPOSEnum.State, rights: '{"0": 7 }' },
  // },
];

@NgModule({
  imports: [
    SharedModule,
    RouterModule.forChild(routes)
  ],
  declarations: [
  ],
  providers: [MasterService, MasterResolver]
})
export class MasterModule { }




