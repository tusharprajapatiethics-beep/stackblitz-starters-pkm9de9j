import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ApiResponse } from '../../common-services/models.service';

@Injectable()
export class MasterService {

    // masterUrl = {
    //     1: { 'List': 'state/list', 'Save': 'state/save', 'Delete': 'state/delete', 'Filter': 'state/filter', 'isExists': '' },
    //     2: { 'List': 'city/list', 'Save': 'city/save', 'Delete': 'city/delete', 'Filter': 'city/filter', 'isExists': '' },
    //     3: { 'List': 'company/list', 'Save': 'company/save', 'Delete': 'company/delete', 'Filter': 'company/filter', 'isExists': '' },
    //     4: { 'List': 'destination/list', 'Save': 'destination/save', 'Delete': 'destination/delete', 'Filter': 'destination/filter', 'isExists': '' },
    //     5: { 'List': 'expense/list', 'Save': 'expense/save', 'Delete': 'expense/delete', 'Filter': 'expense/filter', 'isExists': '' },
    //     6: { 'List': 'marfatia/filter', 'Save': 'marfatia/save', 'Delete': 'marfatia/delete', 'Filter': 'marfatia/filter', 'isExists': 'marfatia/isexists?name=' },
    //     7: { 'List': 'item/list', 'Save': 'item/save', 'Delete': 'item/delete', 'Filter': 'item/filter', 'isExists': '' },
    //     8: { 'List': 'truckowner/list', 'Save': 'truckowner/save', 'Delete': 'truckowner/delete', 'Filter': 'truckowner/filter', 'isExists': '' },
    //     9: { 'List': 'truckmaster/list', 'Save': 'truckmaster/save', 'Delete': 'truckmaster/delete', 'Filter': 'truckmaster/filter', 'isExists': '' },
    //     10:{ 'List': 'marfatiafreight/list', 'Save': 'marfatiafreight/save', 'Delete': 'marfatiafreight/delete', 'Filter': 'marfatiafreight/filter', 'isExists': ''},
    //     11:{ 'List': 'consignee/list','Save':  'consignee/save','Delete':'consignee/delete','Filter':'consignee/filter','isExists':''},
    //     12:{ 'List': 'consigner/list','Save': 'consigner/save','Delete':'consigner/delete','Filter':'consigner/filter','isExists':''},
    //     15:{ 'List': 'expensedetails/list','Save':'expensedetails/save','Delete':'expensedetails/delete','Filter':'expensedetails/filter','isExists':'' }
    // };

    // constructor(private httpClient: HttpClient) { }

    // filter(master: MastersEnum, param1: any = null): Observable<ApiResponse> {
    //     return this.httpClient.post<ApiResponse>(this.masterUrl[master].Filter, param1).map(t => t);
    // }

    // getList(master: MastersEnum, param1: any = null): Observable<any> {
    //     return this.httpClient.get<any[]>(this.masterUrl[master].List).map(t => t);
    // }

    // save(master: MastersEnum, param1: any = null): Observable<ApiResponse> {
    //     return this.httpClient.post<ApiResponse>(this.masterUrl[master].Save, param1).map(t => t);
    // }

    // isExists(master: MastersEnum, param1: any = null): Observable<ApiResponse> {
    //     return this.httpClient.get<ApiResponse>(this.masterUrl[master].isExists + param1);
    // }

    // delete(master: MastersEnum, param1: any = null): Observable<any> {
    //     return this.httpClient.post<any>(this.masterUrl[master].Delete, param1).map(t => t);
    // }
}

